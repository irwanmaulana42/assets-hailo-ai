#!/usr/bin/env python
from hailo_platform.pyhailort.hailo_control_protocol import * # noqa F401